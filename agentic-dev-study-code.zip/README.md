# Agentic Development Practices: Empirical Study

A reproducible data-analysis pipeline for the academic paper *"Agentic Development Practices in Open-Source Repositories: Adoption, Tooling, and Productivity — An Empirical Study"*.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run the full pipeline
python src/analyze.py
```

All outputs land in `output/`:

| Directory | Contents |
|-----------|----------|
| `output/figures/` | 8 publication-quality PNG + PDF figures |
| `output/tables/` | 7 CSV tables |
| `output/analysis_results.json` | Hypothesis-test statistics |

## What It Does

| Stage | Description |
|-------|-------------|
| **Data Loading** | Curated datasets drawn from 12+ public sources (see `SOURCES.md`) |
| **Figure Generation** | 8 figures via matplotlib + seaborn (300 dpi, Computer Modern serif) |
| **Table Export** | 7 CSV tables matching every table in the paper |
| **Statistical Tests** | Pearson correlations, HHI concentration, log-linear fits |
| **Hypothesis Verification** | 5 hypotheses tested with p-values and effect sizes |

## Figures Produced

| # | File | Description |
|---|------|-------------|
| 1 | `fig1_adoption_by_age` | Agent adoption by project age (N = 129 134) |
| 2 | `fig2_platform_landscape` | Users vs ARR scatter plot |
| 3 | `fig3_config_adoption` | Config-file convention repo counts |
| 4 | `fig4_productivity_forest` | Forest plot of 6 productivity studies |
| 5 | `fig5_sdk_trends` | Anthropic vs OpenAI SDK downloads |
| 6 | `fig6_swebench` | SWE-bench score progression 2023-2025 |
| 7 | `fig7_tool_stars` | GitHub stars for agentic tools |
| 8 | `fig8_beads_ecosystem` | Beads community ecosystem |

## Data Verification

Every data point traces to a public source. See **SOURCES.md** for URLs,
access dates, and suggested archive snapshots.

## System Requirements

Python 3.10+, approx. 200 MB disk, no GPU. Runs in < 30 s.

| OS | Status | Notes |
|----|--------|-------|
| Linux (Fedora / Ubuntu) | ✅ | Primary platform |
| macOS 14+ | ✅ | `brew install python` or conda |
| Windows 11 | ✅ | WSL2 or native Python 3.10+ |

## License

MIT — academic citation requested.
