const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.author = "JetBrains Internship Candidate";
pres.title = "Agentic Development Practices: An Empirical Study";

// ── Color Palette: Midnight Executive ──────────────────
const C = {
  navy:   "1E2761",
  ice:    "CADCFC",
  white:  "FFFFFF",
  bg:     "F0F2F8",
  accent: "3B82F6",
  accent2:"10B981",
  red:    "EF4444",
  gold:   "F59E0B",
  dark:   "0F172A",
  muted:  "64748B",
  card:   "FFFFFF",
};

const TITLE_FONT  = "Georgia";
const BODY_FONT   = "Calibri";
const FIG_DIR     = path.join(__dirname, "..", "output", "figures");

function makeShadow() {
  return { type: "outer", blur: 4, offset: 2, angle: 135, color: "000000", opacity: 0.10 };
}

// ═══════════════════════════════════════════════════════
// SLIDE 1: Title
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.navy };
  s.addText("Agentic Development Practices\nin Open-Source Repositories", {
    x: 0.8, y: 0.8, w: 8.4, h: 2.2,
    fontSize: 32, fontFace: TITLE_FONT, color: C.white, bold: true, lineSpacingMultiple: 1.15,
  });
  s.addText("Adoption, Tooling, and Productivity — An Empirical Study", {
    x: 0.8, y: 3.1, w: 8.4, h: 0.6,
    fontSize: 16, fontFace: BODY_FONT, color: C.ice, italic: true,
  });
  s.addShape(pres.shapes.RECTANGLE, {
    x: 0.8, y: 4.0, w: 2.5, h: 0.04, fill: { color: C.accent },
  });
  s.addText("JetBrains Internship — Task 1  |  February 2026", {
    x: 0.8, y: 4.3, w: 8.4, h: 0.5,
    fontSize: 13, fontFace: BODY_FONT, color: C.ice,
  });
  s.addText("129,134 repos  ·  73,543 survey responses  ·  6 data source classes", {
    x: 0.8, y: 4.8, w: 8.4, h: 0.4,
    fontSize: 11, fontFace: BODY_FONT, color: C.muted,
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 2: Research Questions
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("Research Questions", {
    x: 0.6, y: 0.3, w: 9, h: 0.7,
    fontSize: 28, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });

  const rqs = [
    ["RQ1", "How prevalent is AI agent adoption by project age?"],
    ["RQ2", "What is the competitive structure of the tooling market?"],
    ["RQ3", "Which configuration conventions are gaining traction?"],
    ["RQ4", "What do rigorous studies show about productivity?"],
    ["RQ5", "How fast is automated SE capability improving?"],
  ];

  rqs.forEach((rq, i) => {
    const y = 1.2 + i * 0.82;
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 8.8, h: 0.7,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 0.08, h: 0.7, fill: { color: C.accent },
    });
    s.addText(rq[0], {
      x: 0.85, y, w: 0.7, h: 0.7,
      fontSize: 14, fontFace: BODY_FONT, color: C.accent, bold: true, valign: "middle", margin: 0,
    });
    s.addText(rq[1], {
      x: 1.55, y, w: 7.7, h: 0.7,
      fontSize: 14, fontFace: BODY_FONT, color: C.dark, valign: "middle", margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 3: Methodology
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("Methodology: Convergent Mixed-Methods Design", {
    x: 0.6, y: 0.3, w: 9, h: 0.7,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });

  const sources = [
    ["Repository Mining", "129,134 GitHub projects (arXiv:2601.18341)", C.accent],
    ["Developer Surveys", "Stack Overflow + JetBrains (73,543 responses)", C.accent2],
    ["Platform Metrics", "Official data from GitHub, Anthropic, Cursor", C.gold],
    ["Package Registries", "PyPI + npm monthly downloads", "9333EA"],
    ["Benchmarks", "SWE-bench Verified leaderboard", C.red],
    ["Community Signals", "Stars, forks, HN engagement", C.muted],
  ];

  sources.forEach((src, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.6 + col * 3.1;
    const y = 1.2 + row * 1.85;

    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 2.85, h: 1.6,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x, y, w: 2.85, h: 0.06, fill: { color: src[2] },
    });
    s.addText(src[0], {
      x: x + 0.15, y: y + 0.2, w: 2.55, h: 0.4,
      fontSize: 13, fontFace: BODY_FONT, color: C.dark, bold: true, margin: 0,
    });
    s.addText(src[1], {
      x: x + 0.15, y: y + 0.65, w: 2.55, h: 0.8,
      fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 4: Adoption by Project Age (Figure 1)
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("RQ1: Agent Adoption by Project Age", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });

  s.addImage({
    path: path.join(FIG_DIR, "fig1_adoption_by_age.png"),
    x: 0.3, y: 1.0, w: 6.0, h: 3.7,
  });

  // Key stats cards
  const stats = [
    ["21.17%", "Projects < 1 yr"],
    ["4.69%", "Projects > 10 yr"],
    ["r = −0.86", "Age–adoption\ncorrelation"],
  ];
  stats.forEach((st, i) => {
    const y = 1.1 + i * 1.3;
    s.addShape(pres.shapes.RECTANGLE, {
      x: 6.7, y, w: 3.0, h: 1.1,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addText(st[0], {
      x: 6.85, y: y + 0.08, w: 2.7, h: 0.5,
      fontSize: 22, fontFace: TITLE_FONT, color: C.accent, bold: true, margin: 0,
    });
    s.addText(st[1], {
      x: 6.85, y: y + 0.6, w: 2.7, h: 0.45,
      fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 5: Market Structure (Figure 2)
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("RQ2: Three-Way Oligopoly (HHI = 5,801)", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig2_platform_landscape.png"),
    x: 0.3, y: 1.0, w: 5.8, h: 4.0,
  });

  // Market share table
  const rows = [
    [{ text: "Platform", options: { bold: true, color: C.white, fill: { color: C.navy } } },
     { text: "Users", options: { bold: true, color: C.white, fill: { color: C.navy } } },
     { text: "ARR", options: { bold: true, color: C.white, fill: { color: C.navy } } }],
    ["Copilot", "20 M", "$400M"],
    ["Cursor", "1 M", "$1B"],
    ["Claude Code", "115 K", "$2.5B*"],
    ["Cline", "4 M inst.", "OSS"],
    ["Windsurf", "500 K", "$82M"],
  ];
  s.addTable(rows, {
    x: 6.3, y: 1.1, w: 3.4,
    fontSize: 10, fontFace: BODY_FONT, color: C.dark,
    border: { pt: 0.5, color: "E2E8F0" },
    colW: [1.3, 1.0, 1.1],
    rowH: [0.35, 0.3, 0.3, 0.3, 0.3, 0.3],
  });
  s.addText("*Anthropic total ARR", {
    x: 6.3, y: 3.2, w: 3.4, h: 0.3,
    fontSize: 8, fontFace: BODY_FONT, color: C.muted, margin: 0,
  });
  s.addText("Top 3 = 93.8% of users\nHHI > 2,500 = highly concentrated", {
    x: 6.3, y: 3.6, w: 3.4, h: 0.9,
    fontSize: 12, fontFace: BODY_FONT, color: C.dark, margin: 0,
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 6: Config File Conventions (Figure 3)
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("RQ3: AGENTS.md Leads Volume, CLAUDE.md Leads Intensity", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 22, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig3_config_adoption.png"),
    x: 0.3, y: 1.0, w: 5.8, h: 3.5,
  });

  s.addShape(pres.shapes.RECTANGLE, {
    x: 6.4, y: 1.1, w: 3.3, h: 3.2,
    fill: { color: C.card }, shadow: makeShadow(),
  });
  s.addText("Key Findings", {
    x: 6.55, y: 1.2, w: 3.0, h: 0.4,
    fontSize: 14, fontFace: BODY_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addText([
    { text: "AGENTS.md: ", options: { bold: true, breakLine: false } },
    { text: "60K+ repos, cross-platform standard (Linux Foundation)", options: { breakLine: true } },
    { text: "", options: { breakLine: true, fontSize: 6 } },
    { text: "CLAUDE.md: ", options: { bold: true, breakLine: false } },
    { text: "45K repos, 24.1h median update interval (highest intensity)", options: { breakLine: true } },
    { text: "", options: { breakLine: true, fontSize: 6 } },
    { text: "17% of repos ", options: { bold: true, breakLine: false } },
    { text: "use ALL three major formats simultaneously", options: { breakLine: true } },
  ], {
    x: 6.55, y: 1.65, w: 3.0, h: 2.5,
    fontSize: 11, fontFace: BODY_FONT, color: C.dark, margin: 0,
    lineSpacingMultiple: 1.3,
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 7: Productivity Paradox (Figure 4)
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("RQ4: The Productivity Paradox", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig4_productivity_forest.png"),
    x: 0.3, y: 1.0, w: 6.0, h: 3.5,
  });

  // Callout box
  s.addShape(pres.shapes.RECTANGLE, {
    x: 6.5, y: 1.1, w: 3.2, h: 2.5,
    fill: { color: "FEF2F2" }, shadow: makeShadow(),
  });
  s.addText("74.8 pp spread", {
    x: 6.65, y: 1.2, w: 2.9, h: 0.5,
    fontSize: 20, fontFace: TITLE_FONT, color: C.red, bold: true, margin: 0,
  });
  s.addText("From +55.8% (lab RCT)\nto −19% (field RCT)\n\nMETR: devs 19% slower\nbut believed 20% faster\n\nTask type & experience\ndominate outcomes", {
    x: 6.65, y: 1.8, w: 2.9, h: 2.0,
    fontSize: 11, fontFace: BODY_FONT, color: C.dark, margin: 0,
    lineSpacingMultiple: 1.25,
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 8: SWE-bench (Figure 6)
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("RQ5: Near-Exponential Capability Growth", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig6_swebench.png"),
    x: 0.3, y: 1.0, w: 6.0, h: 3.7,
  });

  const stats = [
    ["19.5×", "improvement\nin 21 months"],
    ["r = 0.95", "log-linear\ncorrelation"],
    ["p = 0.004", "highly\nsignificant"],
  ];
  stats.forEach((st, i) => {
    const y = 1.1 + i * 1.3;
    s.addShape(pres.shapes.RECTANGLE, {
      x: 6.7, y, w: 3.0, h: 1.1,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addText(st[0], {
      x: 6.85, y: y + 0.08, w: 2.7, h: 0.5,
      fontSize: 22, fontFace: TITLE_FONT, color: C.accent2, bold: true, margin: 0,
    });
    s.addText(st[1], {
      x: 6.85, y: y + 0.6, w: 2.7, h: 0.45,
      fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 9: Tool Ecosystem + Beads
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("The Agentic Tool Ecosystem & Beads", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig7_tool_stars.png"),
    x: 0.2, y: 1.0, w: 4.8, h: 3.0,
  });
  s.addImage({
    path: path.join(FIG_DIR, "fig8_beads_ecosystem.png"),
    x: 5.1, y: 1.0, w: 4.7, h: 3.0,
  });

  s.addText("Beads: 3-layer architecture (CLI → SQLite → JSONL/Git) · 240K lines Go · 175 commands · 15 community tools", {
    x: 0.6, y: 4.2, w: 8.8, h: 0.5,
    fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
  });
  s.addText("Gas Town: Multi-agent orchestrator built on Beads — formulas, gates, slots, wisps, swarm", {
    x: 0.6, y: 4.65, w: 8.8, h: 0.4,
    fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 10: Hypothesis Results Summary
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("Hypothesis Test Results", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });

  const results = [
    ["H1", "Adoption ↓ with project age", "r = −0.86, p = 0.064", "Directionally\nconfirmed", C.gold],
    ["H2", "Productivity varies by design", "−19% to +55.8%", "Confirmed", C.accent2],
    ["H3", "AGENTS.md vol / CLAUDE.md maint.", "60K vs 24.1h updates", "Partially\nconfirmed", C.gold],
    ["H4", "Three-platform oligopoly", "HHI = 5,801", "Confirmed", C.accent2],
    ["H5", "SWE-bench log-linear growth", "r = 0.95, p = 0.004", "Confirmed", C.accent2],
  ];

  results.forEach((r, i) => {
    const y = 1.1 + i * 0.85;
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 8.8, h: 0.72,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 0.08, h: 0.72, fill: { color: r[4] },
    });
    s.addText(r[0], {
      x: 0.85, y, w: 0.5, h: 0.72,
      fontSize: 13, fontFace: BODY_FONT, color: C.accent, bold: true, valign: "middle", margin: 0,
    });
    s.addText(r[1], {
      x: 1.4, y, w: 3.0, h: 0.72,
      fontSize: 12, fontFace: BODY_FONT, color: C.dark, valign: "middle", margin: 0,
    });
    s.addText(r[2], {
      x: 4.5, y, w: 2.5, h: 0.72,
      fontSize: 11, fontFace: BODY_FONT, color: C.muted, valign: "middle", margin: 0,
    });
    s.addText(r[3], {
      x: 7.2, y, w: 2.0, h: 0.72,
      fontSize: 11, fontFace: BODY_FONT, color: r[4], bold: true, valign: "middle", margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 11: Discussion & JetBrains Implications
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.bg };
  s.addText("Implications for JetBrains", {
    x: 0.6, y: 0.3, w: 9, h: 0.6,
    fontSize: 24, fontFace: TITLE_FONT, color: C.dark, bold: true, margin: 0,
  });

  const items = [
    ["1", "First-Class AGENTS.md Support", "60K+ repos use it. Cross-platform standard backed by Linux Foundation. IntelliJ IDEs should parse, validate, and auto-generate these files.", C.accent],
    ["2", "Persistent Memory Integration", "Beads-style tools solve the '50 First Dates' problem. IDE hooks for .beads/ directories, dependency visualization, and agent onboarding flows.", C.accent2],
    ["3", "Benchmark-Aware AI Features", "SWE-bench scores growing 19.5× in 21 months. IDE AI features should track this capability frontier and adapt task delegation accordingly.", C.gold],
  ];

  items.forEach((item, i) => {
    const y = 1.15 + i * 1.42;
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 8.8, h: 1.25,
      fill: { color: C.card }, shadow: makeShadow(),
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.6, y, w: 0.08, h: 1.25, fill: { color: item[3] },
    });
    s.addText(item[0], {
      x: 0.85, y: y + 0.05, w: 0.5, h: 0.45,
      fontSize: 24, fontFace: TITLE_FONT, color: item[3], bold: true, margin: 0,
    });
    s.addText(item[1], {
      x: 1.4, y: y + 0.08, w: 7.8, h: 0.4,
      fontSize: 14, fontFace: BODY_FONT, color: C.dark, bold: true, margin: 0,
    });
    s.addText(item[2], {
      x: 1.4, y: y + 0.52, w: 7.8, h: 0.65,
      fontSize: 11, fontFace: BODY_FONT, color: C.muted, margin: 0,
    });
  });
}

// ═══════════════════════════════════════════════════════
// SLIDE 12: Conclusion
// ═══════════════════════════════════════════════════════
{
  const s = pres.addSlide();
  s.background = { color: C.navy };
  s.addText("Conclusion", {
    x: 0.8, y: 0.5, w: 8.4, h: 0.7,
    fontSize: 28, fontFace: TITLE_FONT, color: C.white, bold: true, margin: 0,
  });

  const conclusions = [
    "15.85–22.60% of active GitHub projects now use AI coding agents",
    "Three-platform oligopoly (HHI 5,801) with multi-tool usage (>1.6 agents/project)",
    "Productivity ranges −19% to +55.8% — context and task type dominate outcomes",
    "SWE-bench capability growing near-exponentially (19.5× in 21 months, p=0.004)",
    "AGENTS.md emerging as cross-platform standard; Beads pioneers 'agentic memory'",
  ];

  conclusions.forEach((c, i) => {
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.8, y: 1.5 + i * 0.72, w: 8.4, h: 0.58,
      fill: { color: C.navy },
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.8, y: 1.5 + i * 0.72, w: 0.06, h: 0.58,
      fill: { color: C.accent },
    });
    s.addText(c, {
      x: 1.1, y: 1.5 + i * 0.72, w: 8.0, h: 0.58,
      fontSize: 13, fontFace: BODY_FONT, color: C.ice, valign: "middle", margin: 0,
    });
  });

  s.addText("All code and data are open-source  ·  python src/analyze.py regenerates every result", {
    x: 0.8, y: 4.9, w: 8.4, h: 0.4,
    fontSize: 11, fontFace: BODY_FONT, color: C.muted, italic: true,
  });
}

// ═══════════════════════════════════════════════════════
// WRITE FILE
// ═══════════════════════════════════════════════════════
const outPath = path.join(__dirname, "..", "output", "presentation.pptx");
pres.writeFile({ fileName: outPath }).then(() => {
  console.log("✅ Presentation written to", outPath);
}).catch(err => {
  console.error("Error:", err);
});
