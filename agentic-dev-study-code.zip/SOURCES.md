# Data Sources and Verification Guide

Every quantitative claim in the paper and code traces to one or more of the
sources below. Accessed February 2026 unless noted otherwise.

## Primary Research Papers

| ID | Citation | URL | Key Data |
|----|----------|-----|----------|
| S1 | Robbes et al., "Agentic Much? Adoption of Coding Agents on GitHub," arXiv:2601.18341, Jan 2026 | https://arxiv.org/abs/2601.18341 | 129 134-repo adoption rates, file/commit heuristics, age stratification |
| S2 | Murillo et al., "Agent READMEs: An Empirical Study of Context Files for Agentic Coding," arXiv:2511.12884, Nov 2025 | https://arxiv.org/abs/2511.12884 | Config-file maintenance intervals, line counts |
| S3 | Peng et al., "The Impact of AI on Developer Productivity," arXiv:2302.06590, Feb 2023 | https://arxiv.org/abs/2302.06590 | 55.8 % speedup RCT (N = 95) |
| S4 | Cui et al., "AI-Assisted Code Generation in the Enterprise," 2024 | Microsoft Research + Accenture field experiment | 12.9–21.8 % PR increase |
| S5 | METR, "Measuring the Impact of Early AI Coding Agents," 2025 | https://metr.org/Early_AI_Coding_Agents_Report.pdf | −19 % effect in experienced OSS devs |

## Developer Surveys

| ID | Source | URL | Key Data |
|----|--------|-----|----------|
| S6 | Stack Overflow Developer Survey 2025 | https://survey.stackoverflow.co/2025/ | 84 % AI use, 51 % daily, trust metrics |
| S7 | JetBrains Developer Ecosystem 2025 | https://www.jetbrains.com/lp/devecosystem-2025/ | 85 % AI use, 20 % save 8+ hr/wk |
| S8 | GitHub Octoverse 2025 | https://github.blog/news-insights/octoverse/octoverse-2025/ | 80 % new devs try Copilot wk 1, 178 % SDK growth |
| S9 | Greptile State of AI Coding 2025 | https://www.greptile.com/state-of-ai-coding-2025 | CLAUDE.md 67 %, PR size +33 %, dev output +76 % |

## Platform Metrics

| ID | Source | URL | Key Data |
|----|--------|-----|----------|
| S10 | GitHub Copilot 20M users | https://techcrunch.com/2025/07/30/github-copilot-crosses-20-million-all-time-users/ | 20 M all-time users Jul 2025 |
| S11 | Cursor $1B ARR, Series D | https://www.cursor.com/blog (press, Nov 2025) | $1 B ARR, $29.3 B valuation |
| S12 | Claude Code 115 K devs | https://ppc.land/claude-code-reaches-115-000-developers-processes-195-million-lines-weekly/ | 115 K devs, 195 M lines/wk |
| S13 | Anthropic $2.5B ARR | Various press (Feb 2026) | $2.5 B ARR total (Claude Code contribution) |
| S14 | Windsurf 500 K users | https://x.com/deedydas/status/1893040524287971437 | 500 K+ active users |
| S15 | Devin 67 % merge rate | https://cognition.ai/blog/devin-annual-performance-review-2025 | 67 % PR merge, $73 M ARR |
| S16 | Cline VS Code installs | https://marketplace.visualstudio.com/items?itemName=saoudrizwan.claude-dev | 3–5 M installs |
| S17 | Roo Code VS Code installs | https://marketplace.visualstudio.com/items?itemName=RooVeterinaryInc.roo-cline | 1.2 M installs |

## GitHub Repositories (Star Counts)

| Repository | URL | Verified |
|------------|-----|----------|
| github/spec-kit | https://github.com/github/spec-kit | Stars page |
| obra/superpowers | https://github.com/nichochar/superpowers | Stars page |
| PatrickJS/awesome-cursorrules | https://github.com/PatrickJS/awesome-cursorrules | Stars page |
| eyaltoledano/claude-task-master | https://github.com/eyaltoledano/claude-task-master | Stars page |
| agentsmd/agents.md | https://github.com/agentsmd/agents.md | Stars page |
| steveyegge/beads | https://github.com/steveyegge/beads | Stars page |
| steveyegge/gastown | https://github.com/steveyegge/gastown | Stars page |

## Beads Ecosystem

| Tool | URL |
|------|-----|
| beads_rust | https://github.com/Dicklesworthstone/beads_rust |
| beads_viewer | https://github.com/Dicklesworthstone/beads_viewer |
| mcp_agent_mail | https://github.com/Dicklesworthstone/mcp_agent_mail |
| beads-tui | https://github.com/andynu/beads-tui |
| opencode-beads | https://github.com/simonwjackson/opencode-beads |
| Community tools list | https://github.com/steveyegge/beads/blob/main/docs/COMMUNITY_TOOLS.md |

## Configuration-File Adoption

| Claim | Source |
|-------|--------|
| AGENTS.md 60 K+ repos | Medium/@sagarpatiler (Feb 2026); InfoQ 20 K+ (Aug 2025) |
| CLAUDE.md 67 % of AI-config repos | Greptile State of AI Coding 2025 (S9) |
| AGENTS.md Linux Foundation transfer | https://www.infoq.com/news/2025/08/agents-md/ |
| 24.1 h median CLAUDE.md update | arXiv:2511.12884 (S2) |

## SWE-bench

| Score | System | Source |
|-------|--------|--------|
| 3.8 % | Initial LLM | swebench.com leaderboard |
| 50.8 % | Agentless + Claude 3.5 | swebench.com (Dec 2024) |
| 74 %+ | Mini-SWE-agent + Claude 3.7 | swebench.com (2025) |

## Market Size

| Claim | Source |
|-------|--------|
| $7.37 B market (2025) | Mordor Intelligence AI Code Tools report |
| $24–30 B by 2030 | Mordor Intelligence + CB Insights |
| Anthropic/OpenAI SDK ratio 47:1 → 4.2:1 | Greptile (S9) |

## How to Verify

1. **Papers**: All arXiv papers are freely accessible. Search the ID on https://arxiv.org.
2. **GitHub stars**: Visit each URL; star count appears on the repo page header.
3. **Surveys**: SO and JetBrains surveys publish full methodology and results online.
4. **Platform metrics**: Press releases and blog posts are linked above.
5. **Package downloads**: Check https://pypistats.org and https://npmtrends.com.
6. **Archive snapshots**: Use https://web.archive.org for any URL that may change.
